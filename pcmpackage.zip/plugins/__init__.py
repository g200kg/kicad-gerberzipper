import pcbnew
from .gerber_zipper_action import GerberZipperAction

GerberZipperAction().register()
